export interface IEmailbox {
  uuid: string;
}

export { default } from './termsPresenter';

export { default } from './privacyPresenter';

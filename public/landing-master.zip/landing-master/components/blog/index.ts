export { default } from './blogInteractor';

export { default } from './footerPresenter';
